#!/usr/bin/env python3
import cv2
import numpy as np
import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf

import dbus, dbus.service

from dbus.mainloop.glib import DBusGMainLoop
DBusGMainLoop(set_as_default=True)

builder = Gtk.Builder()
builder.add_from_file("mkbackup.ui")


class Handler:
    def onDeleteWindow(self, *args):
        Gtk.main_quit(*args)

    def toggleGreyscale(self, *args):
        global greyscale
        greyscale = ~ greyscale

window = builder.get_object("window1")
scrolledwindow = builder.get_object("scrolledwindow1")
listbox = Gtk.ListBox()
listbox.set_selection_mode(Gtk.SelectionMode.NONE)
scrolledwindow.add(listbox)
window.show_all()
builder.connect_signals(Handler())
Getter = dbus.SystemBus().get_object("at.xundeenergie.mkbackup", "/at/xundeenergie/mkbackup/Status")

def _set_listener():
    print("Listener set")
    dbus.SystemBus().add_signal_receiver(
            path="/at/xundeenergie/mkbackup/Status", 
            handler_function=_progress,
            dbus_interface="at.xundeenergie.mkbackup.Status",
            signal_name='sig_update')
    
def _progress(intv, progr, *args, **kwargs):
    progressbar[intv].set_fraction(progr/100)


def on_switch_activated(switch, gparam):
    intv='X'
    print("S",switch,gparam)
    if switch.get_active():
        state = "on"
    else:
        state = "off"
    print("Switch %s was turned %s" % (intv, state))
    
_set_listener()

def show_frame(*args):
    progressbar=dict()
    for intv in Getter.Names():
        props = Getter.Props(intv)
        row = Gtk.ListBoxRow()
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=50)
        row.add(hbox)
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        hbox.pack_start(vbox, True, True, 0)

        label1 = Gtk.Label(intv, xalign=0)
        label2 = Gtk.Label("bla", xalign=0)
        vbox.pack_start(label1, True, True, 0)
        vbox.pack_start(label2, True, True, 0)

        switch = Gtk.Switch()
        switch.props.valign = Gtk.Align.CENTER
        switch.connect('notify::active', on_switch_activated)
        hbox.pack_start(switch, False, True, 0)

        listbox.add(row)

        row = Gtk.ListBoxRow()
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=50)
        row.add(hbox)
        label = Gtk.Label("Enable Transfer to BKP", xalign=0)
        check = Gtk.CheckButton()
        check.set_active(props['transfer'])
        hbox.pack_start(label, True, True, 0)
        hbox.pack_start(check, False, True, 0)

        listbox.add(row)

        progressbar[intv] = Gtk.ProgressBar()
        progressbar[intv].set_fraction(props['progress']/100)

        listbox.add(progressbar[intv])
        print(props['transfer'])

    return False

GLib.idle_add(show_frame)
Gtk.main()

import dbus
import dbus.service
import random
import time

from mkbackup_btrfs_config import Config, MountInfo, connect, Myos, __version__
config = Config()

from system_notification_emitter import Emitter
class Notification(Emitter):
    def __init__(self):
        super().__init__(conn=dbus.SystemBus(), object_path='/at/xundeenergie/notifications/advanced/Notification')

import threading
class SlowThread(object):
    def __init__(self, bits, callback):
        self._callback = callback
        self.result = ''

        self.thread = threading.Thread(target=self.work, args=(bits,))
        self.thread.start()
        self.thread_id = str(self.thread.ident)

    def work(self, bits):
        num = ''

        while True:
            num += str(random.randint(0, 1))
            bits -= 1
            time.sleep(1)

            if bits <= 0:
                break

        self._callback(self.thread_id, str(int(num, 2)))

class Status(dbus.service.Object):
    def __init__(self, bus_name):
        super().__init__(bus_name, "/at/xundeenergie/mkbackup/Status")
        self._bus = dbus.SystemBus()
        self.stati = dict()
        self.stati[None] = None
        self.notification = Notification()

        for i in config.ListIntervals():
            self.stati[i] = dict()
            self.stati[i]['progress'] = 0
            self.stati[i]['trans'] = config.getTransfer(i)
            self.stati[i]['lastrun'] = 0 
            self.stati[i]['finished'] = True
        self._set_listeners()

        
    def _set_listeners(self):
        """
        dbus-send --system "/at/xundeenergie/mkbackup/Status"
        --dest="at.xundeenergie.mkbackup"
        "at.xundeenergie.mkbackup.Status.progress" string:hourly "int16:10"
        """
        update = self._bus.add_signal_receiver(
                path="/at/xundeenergie/mkbackup/Status", 
                handler_function=self._progress,
                dbus_interface="at.xundeenergie.mkbackup.Status",
                signal_name='update')

        finished = self._bus.add_signal_receiver(
                path="/at/xundeenergie/mkbackup/Status", 
                handler_function=self._finished,
                dbus_interface="at.xundeenergie.mkbackup.Status",
                signal_name='finished')

        start = self._bus.add_signal_receiver(
                path="/at/xundeenergie/mkbackup/Status", 
                handler_function=self._start,
                dbus_interface="at.xundeenergie.mkbackup.Status",
                signal_name='start')

        reset = self._bus.add_signal_receiver(
                path="/at/xundeenergie/mkbackup/Status", 
                handler_function=self._reset,
                dbus_interface="at.xundeenergie.mkbackup.Status",
                signal_name='reset')

    def _start(self, intv):
        self.stati[intv]['progress'] = 0
        if self.stati[intv]['finished']:
            print("Reset %s first" % (intv))
            return
        print("%s start" % (intv))

    def _progress(self, intv, progr):
        if progr >= 0 and not self.stati[intv]['finished']:
            if 0 < self.stati[intv]['progress'] + progr <= 99: 
                self.stati[intv]['progress'] += progr
                print("%s run progress: %i/100%%" % (str(intv),
                    int(self.stati[intv]['progress'])))
            else:
                self.stati[intv]['progress'] = 99
        self.sig_update(intv, self.stati[intv]['progress'])
        print("Progress: %s" % (self.stati[intv]['progress']))

    def _finished(self, intv):
        self.stati[intv]['finished'] = True
        self.stati[intv]['progress'] = 100
        self._send_notification(body="%s finished" % (intv))
        self.sig_update(intv, self.stati[intv]['progress'])
        print("%s finished" % (intv))

    def _reset(self, intv):
        self.stati[intv]['finished'] = False
        self.stati[intv]['progress'] = 0
        print("%s reset" % (intv))

    def _send_notification(self, header="backup", body="Unconfigured Message"):
        msg = dict()
        msg['sender'] = "mkbackup"
        msg['header'] = header
        msg['body'] = body 
        self.notification.normal(msg)


    @dbus.service.method("at.xundeenergie.mkbackup.Intervalls",
                         in_signature='', out_signature='v')
    def Names(self):
        return config.ListIntervals()

    @dbus.service.method("at.xundeenergie.mkbackup.Intervalls",
                         in_signature='s', out_signature='v')
    def Progress(self,intv):
        return self.stati[intv]['progress']

    @dbus.service.method("at.xundeenergie.mkbackup.Intervalls",
                         in_signature='s', out_signature='a{sv}')
    def Props(self,intv):
        return {
                'progress': self.stati[intv]['progress'], 
                'transfer': self.stati[intv]['trans'],
                'lastrun': self.stati[intv]['lastrun'],
                'finished': self.stati[intv]['finished']
                }

    @dbus.service.signal("at.xundeenergie.mkbackup.Status", signature='si')
    def sig_update(self, intv, progr):
        pass

    @dbus.service.signal("at.xundeenergie.mkbackup.Status", signature='si')
    def sig_finished(self, intv, progr):
        pass

#class Notifications(dbus.service.Object):
#    def __init__(self, bus_name):
#        super().__init__(bus_name, "/at/xundeenergie/mkbackup/Status")
#
#        random.seed()
#
#    @dbus.service.method("at.xundeenergie.mkbackup.Status",
#                         in_signature='i', out_signature='s')
#    def quick(self, bits=8):
#        return str(random.getrandbits(bits))
#
#    @dbus.service.method("at.xundeenergie.mkbackup.Status",
#                         in_signature='i', out_signature='s')
#    def slow(self, bits=8):
#        thread = SlowThread(bits, self.slow_result)
#        return thread.thread_id
#
#    @dbus.service.signal("at.xundeenergie.mkbackup.Status", signature='ss')
#    def slow_result(self, thread_id, result):
#        pass
#   
#   
